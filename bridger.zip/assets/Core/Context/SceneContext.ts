import ProjectContext from "db://assets/Core/Context/ProjectContext";
import {Context} from "db://assets/Core/Context/Context";

export class SceneContext extends Context {
    protected projectContext: ProjectContext;

    public Init(pContext: ProjectContext) {

    }
}