System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/ACER/Documents/CocosProjects/bridger/assets/Core/Context/StartSceneContext.ts at runtime.
      throw new Error("SyntaxError: C:Program Files (x86)CocosDashboard\file:C:UsersACERDocumentsCocosProjects\bridgerassetsCoreContextStartSceneContext.ts: Unexpected token (32:4)\n\n  30 |         this.projectContext = pContext;\n  31 |         this.startButton.clickEvents +=\n> 32 |     }\n     |     ^\n  33 | }\n  34 |\n  35 | export default StartSceneContext;");
    }
  };
});
//# sourceMappingURL=ed3466a7d08a19c6d50c72610d4274150b83cb07.js.map