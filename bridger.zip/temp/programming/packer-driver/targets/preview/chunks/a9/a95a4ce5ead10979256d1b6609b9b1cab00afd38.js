System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/ACER/Documents/CocosProjects/bridger/assets/Core/GameStateMachine.ts at runtime.
      throw new Error("SyntaxError: C:Program Files (x86)CocosDashboard\file:C:UsersACERDocumentsCocosProjects\bridgerassetsCoreGameStateMachine.ts: Unexpected token (34:40)\n\n  32 |                 .getScene()\n  33 |                 .getChildByName('StartSceneContext')\n> 34 |                 .getComponent<T>(() => ())\n     |                                         ^\n  35 |                 .Init(pContext);\n  36 |         }));\n  37 |     }");
    }
  };
});
//# sourceMappingURL=a95a4ce5ead10979256d1b6609b9b1cab00afd38.js.map