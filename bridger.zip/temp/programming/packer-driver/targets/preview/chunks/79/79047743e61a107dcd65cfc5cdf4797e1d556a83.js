System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, Component, sys, _decorator, PlayerData, _dec, _class, _crd, ccclass, property, SaveLoad;

  _export("PlayerData", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      Component = _cc.Component;
      sys = _cc.sys;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "6d5d61G4pZEgb6nm27HTWXo", "SaveLoad", undefined);

      __checkObsolete__(['Component', 'sys', '_decorator']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("SaveLoad", SaveLoad = (_dec = ccclass('SaveLoad'), _dec(_class = class SaveLoad extends Component {
        SaveData(data) {
          sys.localStorage.setItem('userData', JSON.stringify(data));
        }

        LoadData() {
          var item = sys.localStorage.getItem('userData');
          var result;
          if (item != null) result = JSON.parse(sys.localStorage.getItem('userData'));else result = new PlayerData("player", 0);
          return result;
        }

      }) || _class));

      _export("PlayerData", PlayerData = class PlayerData {
        constructor(name, maximumScore) {
          this.name = void 0;
          this.maximumScore = void 0;
          this.name = name;
          this.maximumScore = maximumScore;
        }

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=79047743e61a107dcd65cfc5cdf4797e1d556a83.js.map