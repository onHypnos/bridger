System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, director, SceneStateMachine, Context, SaveLoad, SoundManager, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _crd, ccclass, property, ProjectContext;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfSceneStateMachine(extras) {
    _reporterNs.report("SceneStateMachine", "../SceneStateMachine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfContext(extras) {
    _reporterNs.report("Context", "./Context", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSaveLoad(extras) {
    _reporterNs.report("SaveLoad", "db://assets/Core/Services/SaveLoad", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSoundManager(extras) {
    _reporterNs.report("SoundManager", "db://assets/Core/Services/SoundManager", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      director = _cc.director;
    }, function (_unresolved_2) {
      SceneStateMachine = _unresolved_2.SceneStateMachine;
    }, function (_unresolved_3) {
      Context = _unresolved_3.Context;
    }, function (_unresolved_4) {
      SaveLoad = _unresolved_4.SaveLoad;
    }, function (_unresolved_5) {
      SoundManager = _unresolved_5.SoundManager;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "1d321fLdu9M85UCNGZhAiTV", "ProjectContext", undefined);

      __checkObsolete__(['_decorator', 'Component', 'director']);

      ({
        ccclass,
        property
      } = _decorator);
      ProjectContext = (_dec = ccclass('ProjectContext'), _dec2 = property({
        type: _crd && SceneStateMachine === void 0 ? (_reportPossibleCrUseOfSceneStateMachine({
          error: Error()
        }), SceneStateMachine) : SceneStateMachine
      }), _dec3 = property({
        type: _crd && SaveLoad === void 0 ? (_reportPossibleCrUseOfSaveLoad({
          error: Error()
        }), SaveLoad) : SaveLoad
      }), _dec4 = property({
        type: _crd && SoundManager === void 0 ? (_reportPossibleCrUseOfSoundManager({
          error: Error()
        }), SoundManager) : SoundManager
      }), _dec(_class = (_class2 = class ProjectContext extends (_crd && Context === void 0 ? (_reportPossibleCrUseOfContext({
        error: Error()
      }), Context) : Context) {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "sceneStateMachine", _descriptor, this);

          _initializerDefineProperty(this, "saveLoad", _descriptor2, this);

          _initializerDefineProperty(this, "soundManager", _descriptor3, this);
        }

        Init() {
          director.addPersistRootNode(this.node);
          this.Bind(this.sceneStateMachine);
          this.Bind(this.saveLoad);
          this.Bind(this.soundManager);
          this.soundManager.Init();
          this.sceneStateMachine.Init(this);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "sceneStateMachine", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "saveLoad", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "soundManager", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class);

      _export("default", ProjectContext);

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=dea1c35a33ba601815c88f3b17d5a2ab664bfa8a.js.map