System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, MenuUiPanel, GameUiPanel, EndgameUiPanel, CurtainUI, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _crd, ccclass, property, GameUiMediator;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfMenuUiPanel(extras) {
    _reporterNs.report("MenuUiPanel", "db://assets/Core/UI/MenuUiPanel", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameUiPanel(extras) {
    _reporterNs.report("GameUiPanel", "db://assets/Core/UI/GameUIPanel", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEndgameUiPanel(extras) {
    _reporterNs.report("EndgameUiPanel", "db://assets/Core/UI/EndgameUiPanel", _context.meta, extras);
  }

  function _reportPossibleCrUseOfCurtainUI(extras) {
    _reporterNs.report("CurtainUI", "db://assets/Core/UI/CurtainUI", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      MenuUiPanel = _unresolved_2.default;
    }, function (_unresolved_3) {
      GameUiPanel = _unresolved_3.default;
    }, function (_unresolved_4) {
      EndgameUiPanel = _unresolved_4.EndgameUiPanel;
    }, function (_unresolved_5) {
      CurtainUI = _unresolved_5.CurtainUI;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "bb8e4aCVtRMAYZhGKUK5r/g", "GameUIMediator", undefined);

      __checkObsolete__(['_decorator', 'Component', 'director', 'Button', 'EventHandler', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameUiMediator", GameUiMediator = (_dec = ccclass('GameUiMediator'), _dec2 = property({
        type: _crd && MenuUiPanel === void 0 ? (_reportPossibleCrUseOfMenuUiPanel({
          error: Error()
        }), MenuUiPanel) : MenuUiPanel
      }), _dec3 = property({
        type: _crd && GameUiPanel === void 0 ? (_reportPossibleCrUseOfGameUiPanel({
          error: Error()
        }), GameUiPanel) : GameUiPanel
      }), _dec4 = property({
        type: _crd && EndgameUiPanel === void 0 ? (_reportPossibleCrUseOfEndgameUiPanel({
          error: Error()
        }), EndgameUiPanel) : EndgameUiPanel
      }), _dec5 = property({
        type: _crd && CurtainUI === void 0 ? (_reportPossibleCrUseOfCurtainUI({
          error: Error()
        }), CurtainUI) : CurtainUI
      }), _dec(_class = (_class2 = class GameUiMediator extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "menuPanel", _descriptor, this);

          _initializerDefineProperty(this, "gamePanel", _descriptor2, this);

          _initializerDefineProperty(this, "endgamePanel", _descriptor3, this);

          _initializerDefineProperty(this, "curtain", _descriptor4, this);
        }

        Init() {
          this.menuPanel.Init(this);
          this.gamePanel.Init(this);
          this.endgamePanel.Init(this);
          this.curtain.ShowImmediately();
        }

        ShowMenu() {
          this.HideCurtain().start();
          this.HideAllPanel();
          this.menuPanel.Show();
        }

        ShowGame() {
          this.HideAllPanel();
          this.gamePanel.Show();
        }

        ShowEndgame(beatHighScore) {
          this.HideAllPanel();
          this.endgamePanel.Show();
          this.endgamePanel.BeatHighScore(beatHighScore);
        }

        HideAllPanel() {
          this.menuPanel.Hide();
          this.gamePanel.Hide();
          this.endgamePanel.Hide();
        }

        ShowCurtain() {
          return this.curtain.ShowCurtain();
        }

        HideCurtain() {
          return this.curtain.HideCurtain();
        }

        BindRestartButton(restartGameCallback) {
          var show = this.ShowCurtain();

          var restart = () => {
            show.call(restartGameCallback).start();
          };

          this.endgamePanel.BindRestart(restart);
        }

        BindHomeButton(homeCallback) {
          var show = this.ShowCurtain();

          var home = () => {
            show.call(homeCallback).start();
          };

          this.endgamePanel.BindHome(home);
        }

        BindStartGameButton(startGameCallback) {
          this.menuPanel.BindStartGame(startGameCallback);
        }

        SetPointsValue(currentScore) {
          this.gamePanel.UpdatePointsValue(currentScore);
          this.endgamePanel.UpdatePointsValue(currentScore);
        }

        SetMaxPointsValue(currentMaximumScore) {
          this.endgamePanel.UpdateMaxPointsValue(currentMaximumScore);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "menuPanel", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "gamePanel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "endgamePanel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "curtain", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=e6cd242b5d808f79203036642b75e9594ce99736.js.map