System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, director, Component, SceneManager, StartSceneContext, _dec, _class, _crd, ccclass, property, GameStateMachine;

  function _reportPossibleCrUseOfSceneManager(extras) {
    _reporterNs.report("SceneManager", "./Services/SceneManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfStartSceneContext(extras) {
    _reporterNs.report("StartSceneContext", "./Context/StartSceneContext", _context.meta, extras);
  }

  function _reportPossibleCrUseOfProjectContext(extras) {
    _reporterNs.report("ProjectContext", "db://assets/Core/Context/ProjectContext", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      director = _cc.director;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      SceneManager = _unresolved_2.SceneManager;
    }, function (_unresolved_3) {
      StartSceneContext = _unresolved_3.default;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "d6906XBNMtGrKJsl592kQz4", "GameCore", undefined);

      __checkObsolete__(['_decorator', 'director', 'Component']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameStateMachine", GameStateMachine = (_dec = ccclass('GameStateMachine'), _dec(_class = class GameStateMachine extends Component {
        constructor() {
          super(...arguments);
          this.sceneManager = void 0;
          this.projectContext = void 0;
        }

        Construct(pContext) {
          this.sceneManager = new (_crd && SceneManager === void 0 ? (_reportPossibleCrUseOfSceneManager({
            error: Error()
          }), SceneManager) : SceneManager)();
          this.projectContext = pContext;
          this.Run();
        }

        Run() {
          this.LoadStartScene();
          return this;
        }

        LoadStartScene() {
          var pContext = this.projectContext;
          this.sceneManager.LoadScene("StartScene", () => {
            director.getScene().getChildByName('StartSceneContext').getComponent(_crd && StartSceneContext === void 0 ? (_reportPossibleCrUseOfStartSceneContext({
              error: Error()
            }), StartSceneContext) : StartSceneContext).Init(pContext);
          });
        }

        LoadGameScene() {
          this.sceneManager.LoadScene("GameScene", () => {});
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=e351856776c9f0b451a4ad72c6e5fbcb16d89412.js.map