System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/ACER/Documents/CocosProjects/bridger/assets/Core/GameStates/GameStateMachine.ts at runtime.
      throw new Error("SyntaxError: C:Program Files (x86)CocosDashboard\file:C:UsersACERDocumentsCocosProjects\bridgerassetsCoreGameStatesGameStateMachine.ts: Unexpected token (43:4)\n\n  41 |     {\n  42 |         this.nextPlatform =\n> 43 |     }\n     |     ^\n  44 |\n  45 |     public EnterTransitionState() {\n  46 |");
    }
  };
});
//# sourceMappingURL=82dc238f38be81dcc03770efb39808aed876112b.js.map