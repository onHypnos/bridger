System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, ProjectContext, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, Bootstrap;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfProjectContext(extras) {
    _reporterNs.report("ProjectContext", "db://assets/Core/Context/ProjectContext", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      ProjectContext = _unresolved_2.default;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "ec01eH+4xtKfKC8iX8WY4Ps", "Bootstrap", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'CCFloat', 'director']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Bootstrap", Bootstrap = (_dec = ccclass('Bootstrap'), _dec2 = property({
        type: _crd && ProjectContext === void 0 ? (_reportPossibleCrUseOfProjectContext({
          error: Error()
        }), ProjectContext) : ProjectContext
      }), _dec(_class = (_class2 = class Bootstrap extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "projectContext", _descriptor, this);
        }

        start() {
          this.projectContext.Init();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "projectContext", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=c3e019f2a1daab685ff2959e23c9502acf69c602.js.map