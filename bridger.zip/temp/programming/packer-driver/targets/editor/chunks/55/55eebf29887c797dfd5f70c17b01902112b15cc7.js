System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, GameUiMediator, PlayerData, SaveLoad, _dec, _class, _crd, ccclass, property, PlayerProfile;

  function _reportPossibleCrUseOfGameSceneContext(extras) {
    _reporterNs.report("GameSceneContext", "db://assets/Core/Context/GameSceneContext", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameUiMediator(extras) {
    _reporterNs.report("GameUiMediator", "db://assets/Core/UI/GameUIMediator", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayerData(extras) {
    _reporterNs.report("PlayerData", "db://assets/Core/Services/SaveLoad", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSaveLoad(extras) {
    _reporterNs.report("SaveLoad", "db://assets/Core/Services/SaveLoad", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      GameUiMediator = _unresolved_2.GameUiMediator;
    }, function (_unresolved_3) {
      PlayerData = _unresolved_3.PlayerData;
      SaveLoad = _unresolved_3.SaveLoad;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "79d90UubE5HFL8eZrevwcxC", "PlayerProfile", undefined);

      __checkObsolete__(['_decorator', 'Component', 'director']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PlayerProfile", PlayerProfile = (_dec = ccclass('PlayerProfile'), _dec(_class = class PlayerProfile extends Component {
        constructor(...args) {
          super(...args);
          this.ui = void 0;
          this.currentMaximumScore = void 0;
          this.currentScore = void 0;
          this.saveLoad = void 0;
        }

        Init(pContext) {
          this.ui = pContext.GetDependency(_crd && GameUiMediator === void 0 ? (_reportPossibleCrUseOfGameUiMediator({
            error: Error()
          }), GameUiMediator) : GameUiMediator);
          this.saveLoad = pContext.GetDependency(_crd && SaveLoad === void 0 ? (_reportPossibleCrUseOfSaveLoad({
            error: Error()
          }), SaveLoad) : SaveLoad);
          let data = this.saveLoad.LoadData();
          this.currentMaximumScore = data.maximumScore;
        }

        AddPoints(value) {
          this.UpdatePointsValue(this.currentScore + value);
        }

        ResetPoints() {
          this.UpdatePointsValue(0);
          this.ui.SetMaxPointsValue(this.currentMaximumScore);
        }

        UpdatePointsValue(number) {
          this.currentScore = number;

          if (number > this.currentMaximumScore) {
            this.SaveNewMaximumScore(number);
          }

          this.ui.SetPointsValue(this.currentScore); //todo refactor to reactive
        }

        SaveNewMaximumScore(number) {
          this.currentMaximumScore = number;
        }

        GameOverMaxScoreCheck() {
          let beatHighScore = false;

          if (this.currentScore > this.currentMaximumScore) {
            this.SaveNewMaximumScore(this.currentScore);
            beatHighScore = true;
          }

          this.saveLoad.SaveData(new (_crd && PlayerData === void 0 ? (_reportPossibleCrUseOfPlayerData({
            error: Error()
          }), PlayerData) : PlayerData)("player", this.currentMaximumScore));
          this.ui.ShowEndgame(beatHighScore);
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=55eebf29887c797dfd5f70c17b01902112b15cc7.js.map