System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Tween, tween, Vec3, _dec, _class, _crd, ccclass, property, CharacterMovement;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Tween = _cc.Tween;
      tween = _cc.tween;
      Vec3 = _cc.Vec3;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "2054bnWwZ5BNroSqD43PIm5", "CharacterMovement", undefined);

      __checkObsolete__(['_decorator', 'CCFloat', 'Component', 'director', 'Tween', 'tween', 'Vec3']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("CharacterMovement", CharacterMovement = (_dec = ccclass('CharacterMovement'), _dec(_class = class CharacterMovement extends Component {
        Init() {//init characterAnimator
        }

        Warp(toPosition) {
          this.node.position = toPosition;
        }

        MoveTo(position) {
          //animator.setState(moving);
          return tween(this.node.position).to(.5, position, {
            onUpdate: target => {
              this.node.position = target;
            }
          });
        }

        TranslateTo(position) {
          //animator.setState(idle);
          return tween(this.node.position).to(0.2, position, {
            onUpdate: target => {
              this.node.position = target;
            }
          });
        }

        MoveDown(position) {
          let newPosition = new Vec3(position.x, position.y, position.z); //animator.setState(falling);

          return tween(this.node.position).to(1, position, {
            onUpdate: target => {
              this.node.position = target;
            }
          });
        }

        StopAllMovements() {
          Tween.stopAllByTag(1); //characterAnimator.setState(idle)
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=faec83c9044eaf720bf5f1aa5982dffda98234df.js.map