System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, input, Input, _dec, _class, _crd, ccclass, property, InputEvents, InputHandler;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      input = _cc.input;
      Input = _cc.Input;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "b71cdpI4/BDZo1pYb0Bf9i2", "InputHandler", undefined);

      __checkObsolete__(['_decorator', 'director', 'Component', 'Vec3', 'CCFloat', 'input', 'Input', 'Tween', 'tween', 'Node', 'systemEvent', 'SystemEvent']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("InputEvents", InputEvents = /*#__PURE__*/function (InputEvents) {
        InputEvents["TOUCH_START"] = "TOUCH_START";
        InputEvents["TOUCH_END"] = "TOUCH_END";
        return InputEvents;
      }({}));

      _export("InputHandler", InputHandler = (_dec = ccclass("InputHandler"), _dec(_class = class InputHandler extends Component {
        constructor(...args) {
          super(...args);
          this.eventHandler = new Map();
        }

        //todo refactor for future usage
        Init() {
          let onMouseDown = e => this.Notify(InputEvents.TOUCH_START, e);

          let onMouseUp = e => this.Notify(InputEvents.TOUCH_END, e); //this.AddEventListener(InputEvents.TOUCH_START, (e)=> console.log("mouseDown " + e));
          //this.AddEventListener(InputEvents.TOUCH_END, (e)=> console.log("mouseUP " + e));


          input.on(Input.EventType.TOUCH_START, onMouseDown, this);
          input.on(Input.EventType.TOUCH_END, onMouseUp, this);
        }

        AddEventListener(event, callback) {
          if (!this.eventHandler.has(event)) {
            this.eventHandler.set(event, new Set());
          }

          this.eventHandler.get(event).add(callback);
        }

        RemoveEventListener(event, callback) {
          if (this.eventHandler.has(event)) {
            this.eventHandler.get(event).delete(callback);
          }
        }

        Notify(eventName, e) {
          if (this.eventHandler.has(eventName)) {
            let events = this.eventHandler.get(eventName);

            for (const listner of events) {
              listner == null || listner.call(e);
            }
          }
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=04587df5e867890084705b06580452b85a4f529f.js.map