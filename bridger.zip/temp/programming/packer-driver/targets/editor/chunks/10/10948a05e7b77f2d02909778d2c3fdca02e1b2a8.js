System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _crd;

  function GetRandomNumberInRange(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  _export("GetRandomNumberInRange", GetRandomNumberInRange);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "5b3e85sS7ZIy4vclbo44wqu", "Utils", undefined);

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=10948a05e7b77f2d02909778d2c3fdca02e1b2a8.js.map