System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/ACER/Documents/CocosProjects/bridger/assets/Core/Character/CharacterStick.ts at runtime.
      throw new Error(`Error: Error when fetching file C:\Users\ACER\Documents\CocosProjects\bridger\assets\Core\Character\CharacterStick.ts: Error: ENOENT: no such file or directory, open 'C:\Users\ACER\Documents\CocosProjects\bridger\assets\Core\Character\CharacterStick.ts'`);
    }
  };
});
//# sourceMappingURL=62d43e0418944bfa59e7c2f6ad55d0b87b2c47ef.js.map