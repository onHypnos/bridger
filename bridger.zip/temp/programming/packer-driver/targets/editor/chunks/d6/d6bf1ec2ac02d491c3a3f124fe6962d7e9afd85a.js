System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, Context, SceneContext, _crd;

  function _reportPossibleCrUseOfProjectContext(extras) {
    _reporterNs.report("ProjectContext", "db://assets/Core/Context/ProjectContext", _context.meta, extras);
  }

  function _reportPossibleCrUseOfContext(extras) {
    _reporterNs.report("Context", "db://assets/Core/Context/Context", _context.meta, extras);
  }

  _export("SceneContext", void 0);

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
    }, function (_unresolved_2) {
      Context = _unresolved_2.Context;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "686bcqH1T1NC6C+x0ueJChc", "SceneContext", undefined);

      _export("SceneContext", SceneContext = class SceneContext extends (_crd && Context === void 0 ? (_reportPossibleCrUseOfContext({
        error: Error()
      }), Context) : Context) {
        constructor(...args) {
          super(...args);
          this.projectContext = void 0;
        }

        Init(pContext) {}

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=d6bf1ec2ac02d491c3a3f124fe6962d7e9afd85a.js.map