System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Context, _crd, ccclass, property;

  _export("Context", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "0ed87g+ckRFv6DZNspuWYnx", "Context", undefined);

      __checkObsolete__(['_decorator', 'Component']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Context", Context = class Context extends Component {
        constructor(...args) {
          super(...args);
          this.dependencies = new Map();
        }

        Bind(value) {
          if (value) {
            this.dependencies.set(value.constructor, value);
          } else {
            console.error("Cannot bind null or undefined value. Проверь экземпляр");
          }
        }

        GetDependency(type) {
          return this.dependencies.get(type);
        }

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=b3aad1ac6136da38435ddcf2f4fa8e1ee92c978c.js.map