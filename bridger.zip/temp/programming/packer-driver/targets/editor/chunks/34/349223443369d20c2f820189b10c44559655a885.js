System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/ACER/Documents/CocosProjects/bridger/assets/Core/GameCore.ts at runtime.
      throw new Error(`SyntaxError: C:\Program Files (x86)\CocosDashboard\file:\C:\Users\ACER\Documents\CocosProjects\bridger\assets\Core\GameCore.ts: Missing semicolon. (27:36)

  25 |         {
  26 |             this.node.parent.children.find((e)=>
> 27 |             {typeof(e)==typeof(Game)).Init(pContext);
     |                                     ^
  28 |         }));
  29 |
  30 |     }`);
    }
  };
});
//# sourceMappingURL=349223443369d20c2f820189b10c44559655a885.js.map