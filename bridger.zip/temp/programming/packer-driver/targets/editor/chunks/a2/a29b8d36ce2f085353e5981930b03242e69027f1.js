System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/ACER/Documents/CocosProjects/bridger/assets/Core/Context/StartSceneContext.ts at runtime.
      throw new Error(`SyntaxError: C:\Program Files (x86)\CocosDashboard\file:\C:\Users\ACER\Documents\CocosProjects\bridger\assets\Core\Context\StartSceneContext.ts: Unexpected token (32:4)

  30 |         this.projectContext = pContext;
  31 |         this.startButton.
> 32 |     }
     |     ^
  33 | }
  34 |
  35 | export default StartSceneContext;`);
    }
  };
});
//# sourceMappingURL=a29b8d36ce2f085353e5981930b03242e69027f1.js.map