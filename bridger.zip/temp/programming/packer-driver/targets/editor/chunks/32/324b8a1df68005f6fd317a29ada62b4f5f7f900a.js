System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, director, Component, SceneManager, GameSceneContext, _dec, _class, _crd, ccclass, property, SceneStateMachine;

  function _reportPossibleCrUseOfSceneManager(extras) {
    _reporterNs.report("SceneManager", "./Services/SceneManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfProjectContext(extras) {
    _reporterNs.report("ProjectContext", "db://assets/Core/Context/ProjectContext", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameSceneContext(extras) {
    _reporterNs.report("GameSceneContext", "db://assets/Core/Context/GameSceneContext", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      director = _cc.director;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      SceneManager = _unresolved_2.SceneManager;
    }, function (_unresolved_3) {
      GameSceneContext = _unresolved_3.default;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "f3cc200g01CdbaNdFTpNL1n", "SceneStateMachine", undefined);

      __checkObsolete__(['_decorator', 'director', 'Component']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("SceneStateMachine", SceneStateMachine = (_dec = ccclass('SceneStateMachine'), _dec(_class = class SceneStateMachine extends Component {
        constructor(...args) {
          super(...args);
          this.sceneManager = void 0;
          this.projectContext = void 0;
        }

        Init(pContext) {
          this.sceneManager = new (_crd && SceneManager === void 0 ? (_reportPossibleCrUseOfSceneManager({
            error: Error()
          }), SceneManager) : SceneManager)();
          this.projectContext = pContext;
          this.Run();
        }

        Run() {
          this.LoadGameScene(this.projectContext);
          return this;
        }

        LoadGameScene(pContext) {
          this.sceneManager.LoadScene("2.Game", () => {
            director.getScene().getComponentInChildren(_crd && GameSceneContext === void 0 ? (_reportPossibleCrUseOfGameSceneContext({
              error: Error()
            }), GameSceneContext) : GameSceneContext).Init(pContext);
          });
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=324b8a1df68005f6fd317a29ada62b4f5f7f900a.js.map