System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, director, SceneManager, _crd;

  _export("SceneManager", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      director = _cc.director;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "9c8a8sh6YdD1Lc3ouXJiQVf", "SceneManager", undefined);

      __checkObsolete__(['director']);

      _export("SceneManager", SceneManager = class SceneManager {
        LoadScene(sceneName, callback) {
          director.loadScene(sceneName, callback);
        }

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=dd04e717397afaefe844756f0cf91f9b71f5f080.js.map