System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, SceneManager, _dec, _class, _crd, ccclass, property, GameStateMachine;

  function _reportPossibleCrUseOfSceneManager(extras) {
    _reporterNs.report("SceneManager", "./Services/SceneManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfProjectContext(extras) {
    _reporterNs.report("ProjectContext", "db://assets/Core/Context/ProjectContext", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      SceneManager = _unresolved_2.SceneManager;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "880fctAbZdLF6uLdtUl0SKg", "GameStateMachine", undefined);

      __checkObsolete__(['_decorator', 'director', 'Component']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameStateMachine", GameStateMachine = (_dec = ccclass('GameStateMachine'), _dec(_class = class GameStateMachine extends Component {
        Init(pContext) {
          this.sceneManager = new (_crd && SceneManager === void 0 ? (_reportPossibleCrUseOfSceneManager({
            error: Error()
          }), SceneManager) : SceneManager)();
          this.projectContext = pContext;
          this.Run();
        }

        Run() {
          this.LoadGameScene();
          return this;
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=8357839660ecc0a9dbff7e43e44d4ea3163bb2e1.js.map