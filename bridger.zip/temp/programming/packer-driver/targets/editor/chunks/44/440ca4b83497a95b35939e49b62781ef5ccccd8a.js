System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/ACER/Documents/CocosProjects/bridger/assets/Core/Context/StartSceneContext.ts at runtime.
      throw new Error(`SyntaxError: C:\Program Files (x86)\CocosDashboard\file:\C:\Users\ACER\Documents\CocosProjects\bridger\assets\Core\Context\StartSceneContext.ts: Unexpected token (15:4)

  13 |     @property({
  14 |         type:
> 15 |     })
     |     ^
  16 |
  17 |
  18 |     Bind(value: any): void {`);
    }
  };
});
//# sourceMappingURL=440ca4b83497a95b35939e49b62781ef5ccccd8a.js.map