System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/ACER/Documents/CocosProjects/bridger/assets/Core/GameStates/GameStateMachine.ts at runtime.
      throw new Error(`SyntaxError: C:\Program Files (x86)\CocosDashboard\file:\C:\Users\ACER\Documents\CocosProjects\bridger\assets\Core\GameStates\GameStateMachine.ts: Unexpected token (43:4)

  41 |     {
  42 |         this.nextPlatform =
> 43 |     }
     |     ^
  44 |
  45 |     public EnterTransitionState() {
  46 |`);
    }
  };
});
//# sourceMappingURL=82dc238f38be81dcc03770efb39808aed876112b.js.map