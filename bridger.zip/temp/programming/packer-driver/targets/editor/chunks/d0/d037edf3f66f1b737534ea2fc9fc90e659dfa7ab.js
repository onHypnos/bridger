System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/ACER/Documents/CocosProjects/bridger/assets/Core/Character/CharacterStick.ts at runtime.
      throw new Error(`SyntaxError: C:\Program Files (x86)\CocosDashboard\file:\C:\Users\ACER\Documents\CocosProjects\bridger\assets\Core\Character\CharacterStick.ts: Unexpected token (18:4)

  16 |     {
  17 |         this.transform.
> 18 |     }
     |     ^
  19 | }`);
    }
  };
});
//# sourceMappingURL=d037edf3f66f1b737534ea2fc9fc90e659dfa7ab.js.map