System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5", "__unresolved_6"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Vec3, CCFloat, input, Input, GameUiMediator, CharacterFabric, PlatformFabric, GetRandomNumberInRange, PlayerProfile, SoundManager, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _crd, ccclass, property, GameStateMachine;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfCharacterMediator(extras) {
    _reporterNs.report("CharacterMediator", "db://assets/Core/Character/CharacterMediator", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameUiMediator(extras) {
    _reporterNs.report("GameUiMediator", "db://assets/Core/UI/GameUIMediator", _context.meta, extras);
  }

  function _reportPossibleCrUseOfCharacterFabric(extras) {
    _reporterNs.report("CharacterFabric", "db://assets/Core/Character/CharacterFabric", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlatform(extras) {
    _reporterNs.report("Platform", "db://assets/Core/Character/Platform", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlatformFabric(extras) {
    _reporterNs.report("PlatformFabric", "../Character/PlatformFabric", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameSceneContext(extras) {
    _reporterNs.report("GameSceneContext", "db://assets/Core/Context/GameSceneContext", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGetRandomNumberInRange(extras) {
    _reporterNs.report("GetRandomNumberInRange", "db://assets/Core/Utils/Utils", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayerProfile(extras) {
    _reporterNs.report("PlayerProfile", "db://assets/Core/Services/PlayerProfile", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSoundManager(extras) {
    _reporterNs.report("SoundManager", "db://assets/Core/Services/SoundManager", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Vec3 = _cc.Vec3;
      CCFloat = _cc.CCFloat;
      input = _cc.input;
      Input = _cc.Input;
    }, function (_unresolved_2) {
      GameUiMediator = _unresolved_2.GameUiMediator;
    }, function (_unresolved_3) {
      CharacterFabric = _unresolved_3.CharacterFabric;
    }, function (_unresolved_4) {
      PlatformFabric = _unresolved_4.PlatformFabric;
    }, function (_unresolved_5) {
      GetRandomNumberInRange = _unresolved_5.GetRandomNumberInRange;
    }, function (_unresolved_6) {
      PlayerProfile = _unresolved_6.PlayerProfile;
    }, function (_unresolved_7) {
      SoundManager = _unresolved_7.SoundManager;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "1ea5cabgdRJibNiq1UqTfB4", "GameStateMachine", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Vec3', 'CCFloat', 'input', 'Input']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameStateMachine", GameStateMachine = (_dec = ccclass('GameStateMachine'), _dec2 = property({
        type: Vec3
      }), _dec3 = property({
        type: Vec3
      }), _dec4 = property({
        type: Vec3
      }), _dec5 = property({
        type: Vec3
      }), _dec6 = property({
        type: Vec3
      }), _dec7 = property({
        type: CCFloat
      }), _dec8 = property({
        type: CCFloat
      }), _dec(_class = (_class2 = class GameStateMachine extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "startPlatformDestination", _descriptor, this);

          _initializerDefineProperty(this, "previousPlatformDestination", _descriptor2, this);

          _initializerDefineProperty(this, "currentPlatformDestination", _descriptor3, this);

          _initializerDefineProperty(this, "nextPlatformDestination", _descriptor4, this);

          _initializerDefineProperty(this, "nextPlatformSpawn", _descriptor5, this);

          _initializerDefineProperty(this, "riddleMinValue", _descriptor6, this);

          _initializerDefineProperty(this, "riddleMaxValue", _descriptor7, this);

          this.riddleDistance = void 0;
          this.gameUIMediator = void 0;
          this.playerProfile = void 0;
          this.platformFabric = void 0;
          this.characterFabric = void 0;
          this.soundManager = void 0;
          this.character = void 0;
          this.previousPlatform = void 0;
          this.currentPlatform = void 0;
          this.nextPlatform = void 0;
          this.currentStickValue = void 0;
          this.stickIncreasingSpeed = 200;
          this.increaseStick = void 0;
        }

        Init(ctx) {
          this.gameUIMediator = ctx.GetDependency(_crd && GameUiMediator === void 0 ? (_reportPossibleCrUseOfGameUiMediator({
            error: Error()
          }), GameUiMediator) : GameUiMediator);
          this.platformFabric = ctx.GetDependency(_crd && PlatformFabric === void 0 ? (_reportPossibleCrUseOfPlatformFabric({
            error: Error()
          }), PlatformFabric) : PlatformFabric);
          this.characterFabric = ctx.GetDependency(_crd && CharacterFabric === void 0 ? (_reportPossibleCrUseOfCharacterFabric({
            error: Error()
          }), CharacterFabric) : CharacterFabric);
          this.playerProfile = ctx.GetDependency(_crd && PlayerProfile === void 0 ? (_reportPossibleCrUseOfPlayerProfile({
            error: Error()
          }), PlayerProfile) : PlayerProfile);
          this.soundManager = ctx.GetDependency(_crd && SoundManager === void 0 ? (_reportPossibleCrUseOfSoundManager({
            error: Error()
          }), SoundManager) : SoundManager);
          this.character = this.characterFabric.SpawnCharacter();
          this.character.Init();
          this.gameUIMediator.BindStartGameButton(() => this.StartGame());
          this.gameUIMediator.BindRestartButton(() => this.RestartGame());
          this.gameUIMediator.BindHomeButton(() => this.EnterMenuState());
          this.EnterMenuState();
        } //todo:refactor to different files for each state


        EnterMenuState() {
          this.Reset();
          this.playerProfile.ResetPoints();
          this.currentPlatform = this.platformFabric.GetPlatform();
          this.currentPlatform.HideReward();
          this.currentPlatform.SetSize(100);
          this.currentPlatform.WarpToPosition(this.startPlatformDestination);
          this.character.WarpToPosition(this.startPlatformDestination);
          this.gameUIMediator.ShowMenu();
        }

        StartGame() {
          this.SetupRiddle();
        }

        RestartGame() {
          this.Reset();
          this.playerProfile.ResetPoints();
          this.currentPlatform = this.platformFabric.GetPlatform();
          this.currentPlatform.HideReward();
          this.currentPlatform.SetSize(100);
          this.currentPlatform.WarpToPosition(this.currentPlatformDestination);
          this.character.WarpToPosition(this.GetCharacterPositionOnPlatform());
          this.gameUIMediator.HideCurtain().start();
          this.SetupRiddle();
        }

        SetupRiddle() {
          this.gameUIMediator.ShowGame();
          this.SetupNextPlatform();
          this.riddleDistance = (_crd && GetRandomNumberInRange === void 0 ? (_reportPossibleCrUseOfGetRandomNumberInRange({
            error: Error()
          }), GetRandomNumberInRange) : GetRandomNumberInRange)(this.riddleMinValue, this.riddleMaxValue);
          this.EnterTransitionState();
        }

        SetupNextPlatform() {
          this.nextPlatform = this.platformFabric.GetPlatform();
          this.nextPlatform.Reset();
          this.nextPlatform.WarpToPosition(this.nextPlatformSpawn);
          return this.nextPlatform.RandomiseSize();
        }

        EnterTransitionState() {
          this.currentPlatform.MoveToPosition(this.currentPlatformDestination).start();
          this.character.TranslateToPosition(this.GetCharacterPositionOnPlatform()).start();

          if (this.previousPlatform != null) {
            this.previousPlatform.MoveToPosition(this.previousPlatformDestination).start();
          }

          this.nextPlatformDestination = new Vec3(this.currentPlatformDestination.x + this.riddleDistance, this.currentPlatformDestination.y, 0);
          this.nextPlatform.ShowReward();
          this.nextPlatform.MoveToPosition(this.nextPlatformDestination).call(() => this.EnterPlayerInputState()).start();
        }

        GetCharacterPositionOnPlatform() {
          return new Vec3(this.currentPlatformDestination.x + (this.currentPlatform.platformSize - this.character.GetCurrentVisualWidth()) * 0.5, this.currentPlatformDestination.y, 0);
        }

        EnterPlayerInputState() {
          this.currentStickValue = 0;
          input.once(Input.EventType.TOUCH_START, this.EnableStickIncreasing, this);
        }

        EnableStickIncreasing() {
          this.soundManager.PlayStickSound();
          input.once(Input.EventType.TOUCH_END, this.EnterStickValue, this);
          this.increaseStick = true;
        }

        IncreaseStickValue(deltaTime) {
          this.currentStickValue += deltaTime * this.stickIncreasingSpeed;
          this.currentPlatform.SetStickValue(this.currentStickValue);
        }

        update(deltaTime) {
          if (this.increaseStick) {
            this.IncreaseStickValue(deltaTime);
          }
        }

        EnterStickValue() {
          this.soundManager.StopStickSound();
          this.increaseStick = false;
          this.currentPlatform.RotateStick().call(() => {
            this.ResolveRiddle();
          }).start();
        }

        ResolveRiddle() {
          let startMovingPositionX = this.currentPlatformDestination.x + this.currentPlatform.platformSize * 0.5;
          let range = this.nextPlatformDestination.x - startMovingPositionX;
          let minimumRange = range - this.nextPlatform.platformSize * 0.5;
          let maximumRange = minimumRange + this.nextPlatform.platformSize;
          let minimumRewardedRange = range - this.nextPlatform.rewardSize * 0.5;
          let maximumRewardedRange = minimumRewardedRange + this.nextPlatform.rewardSize;
          let movingPosition = new Vec3(startMovingPositionX + this.currentStickValue, this.character.node.position.y, this.character.node.position.z);
          let fallingPosition = new Vec3(startMovingPositionX + this.currentStickValue, this.character.node.position.y - 800, this.character.node.position.z);
          let tween = this.character.MoveToPosition(movingPosition);

          if (this.currentStickValue >= minimumRange && this.currentStickValue <= maximumRange) {
            if (this.currentStickValue >= minimumRewardedRange && this.currentStickValue <= maximumRewardedRange) {
              this.playerProfile.AddPoints(3);
              this.soundManager.PlayReward();
            } else {
              this.playerProfile.AddPoints(1);
            }

            let setup = () => this.SetupRiddle();

            let shift = () => this.ShiftPlatforms();

            tween.call(() => {
              shift();
              setup();
            }).start();
          } else {
            tween.call(() => this.currentPlatform.RotateStickToFall().start()).then(this.GameOver(fallingPosition)).start();
          }
        }

        ShiftPlatforms() {
          this.previousPlatform = this.currentPlatform;
          this.currentPlatform = this.nextPlatform;
          this.nextPlatform.HideReward();
        }

        GameOver(fallingPosition) {
          let playerProfile = this.playerProfile;
          let sound = this.soundManager;
          return this.character.DropCharacterDown(fallingPosition).call(() => {
            sound.PlayLose();
            playerProfile.GameOverMaxScoreCheck();
          });
        }

        Reset() {
          if (this.currentPlatform != null) {
            this.currentPlatform.Reset();
          }

          if (this.previousPlatform != null) {
            this.previousPlatform.Reset();
          }

          if (this.nextPlatform != null) {
            this.nextPlatform.Reset();
          }

          this.currentPlatform = null;
          this.previousPlatform = null;
          this.nextPlatform = null;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "startPlatformDestination", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "previousPlatformDestination", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "currentPlatformDestination", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "nextPlatformDestination", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "nextPlatformSpawn", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "riddleMinValue", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "riddleMaxValue", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=9a459e66857eca78498790e0c325ea8ff629c6b5.js.map