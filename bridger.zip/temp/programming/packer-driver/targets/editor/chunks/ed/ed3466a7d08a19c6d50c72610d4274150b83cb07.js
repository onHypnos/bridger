System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/ACER/Documents/CocosProjects/bridger/assets/Core/Context/StartSceneContext.ts at runtime.
      throw new Error(`SyntaxError: C:\Program Files (x86)\CocosDashboard\file:\C:\Users\ACER\Documents\CocosProjects\bridger\assets\Core\Context\StartSceneContext.ts: Unexpected token (32:4)

  30 |         this.projectContext = pContext;
  31 |         this.startButton.clickEvents +=
> 32 |     }
     |     ^
  33 | }
  34 |
  35 | export default StartSceneContext;`);
    }
  };
});
//# sourceMappingURL=ed3466a7d08a19c6d50c72610d4274150b83cb07.js.map