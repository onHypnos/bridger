System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, director, SceneManager, _crd;

  _export("SceneManager", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      director = _cc.director;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "a264d7X7ylNBoGJpNu59VHA", "SceneManager", undefined);

      __checkObsolete__(['director']);

      _export("SceneManager", SceneManager = class SceneManager {
        LoadScene(sceneName, callback) {
          director.loadScene(sceneName, callback);
        }

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=8e15a14ad9215c6bec2a331632a1a0bf33045454.js.map