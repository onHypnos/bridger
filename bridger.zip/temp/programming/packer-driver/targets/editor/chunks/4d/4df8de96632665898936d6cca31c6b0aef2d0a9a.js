System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, SceneContext, StartSceneUI, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, StartSceneContext;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfSceneContext(extras) {
    _reporterNs.report("SceneContext", "./Context", _context.meta, extras);
  }

  function _reportPossibleCrUseOfProjectContext(extras) {
    _reporterNs.report("ProjectContext", "./ProjectContext", _context.meta, extras);
  }

  function _reportPossibleCrUseOfStartSceneUI(extras) {
    _reporterNs.report("StartSceneUI", "../UI/GameUIMediator", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      SceneContext = _unresolved_2.SceneContext;
    }, function (_unresolved_3) {
      StartSceneUI = _unresolved_3.default;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "2ae0aJtRbJFa5801sl+P+31", "StartSceneContext", undefined);

      __checkObsolete__(['_decorator', 'Component', 'director', 'Button', 'EventHandler', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);
      StartSceneContext = (_dec = ccclass('StartSceneContext'), _dec2 = property({
        type: _crd && StartSceneUI === void 0 ? (_reportPossibleCrUseOfStartSceneUI({
          error: Error()
        }), StartSceneUI) : StartSceneUI
      }), _dec(_class = (_class2 = class StartSceneContext extends (_crd && SceneContext === void 0 ? (_reportPossibleCrUseOfSceneContext({
        error: Error()
      }), SceneContext) : SceneContext) {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "gameUiMediator", _descriptor, this);
        }

        Init(pContext) {
          this.projectContext = pContext;
          this.gameUiMediator.Init();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "gameUiMediator", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class);

      _export("default", StartSceneContext);

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=4df8de96632665898936d6cca31c6b0aef2d0a9a.js.map