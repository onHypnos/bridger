System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4", "__unresolved_5", "__unresolved_6", "__unresolved_7", "__unresolved_8"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, GameStateMachine, GameUiMediator, CharacterFabric, SceneContext, PlatformFabric, PlayerProfile, SaveLoad, SoundManager, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _crd, ccclass, property, GameSceneContext;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfProjectContext(extras) {
    _reporterNs.report("ProjectContext", "db://assets/Core/Context/ProjectContext", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameStateMachine(extras) {
    _reporterNs.report("GameStateMachine", "db://assets/Core/GameStates/GameStateMachine", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameUiMediator(extras) {
    _reporterNs.report("GameUiMediator", "db://assets/Core/UI/GameUIMediator", _context.meta, extras);
  }

  function _reportPossibleCrUseOfCharacterFabric(extras) {
    _reporterNs.report("CharacterFabric", "db://assets/Core/Character/CharacterFabric", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSceneContext(extras) {
    _reporterNs.report("SceneContext", "db://assets/Core/Context/SceneContext", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlatformFabric(extras) {
    _reporterNs.report("PlatformFabric", "db://assets/Core/Character/PlatformFabric", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayerProfile(extras) {
    _reporterNs.report("PlayerProfile", "db://assets/Core/Services/PlayerProfile", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSaveLoad(extras) {
    _reporterNs.report("SaveLoad", "db://assets/Core/Services/SaveLoad", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSoundManager(extras) {
    _reporterNs.report("SoundManager", "db://assets/Core/Services/SoundManager", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      GameStateMachine = _unresolved_2.GameStateMachine;
    }, function (_unresolved_3) {
      GameUiMediator = _unresolved_3.GameUiMediator;
    }, function (_unresolved_4) {
      CharacterFabric = _unresolved_4.CharacterFabric;
    }, function (_unresolved_5) {
      SceneContext = _unresolved_5.SceneContext;
    }, function (_unresolved_6) {
      PlatformFabric = _unresolved_6.PlatformFabric;
    }, function (_unresolved_7) {
      PlayerProfile = _unresolved_7.PlayerProfile;
    }, function (_unresolved_8) {
      SaveLoad = _unresolved_8.SaveLoad;
    }, function (_unresolved_9) {
      SoundManager = _unresolved_9.SoundManager;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "42db8D4aBdCIIG+4t0YEyEc", "GameSceneContext", undefined);

      __checkObsolete__(['_decorator', 'Component', 'director']);

      ({
        ccclass,
        property
      } = _decorator);
      GameSceneContext = (_dec = ccclass('GameSceneContext'), _dec2 = property({
        type: _crd && GameStateMachine === void 0 ? (_reportPossibleCrUseOfGameStateMachine({
          error: Error()
        }), GameStateMachine) : GameStateMachine
      }), _dec3 = property({
        type: _crd && CharacterFabric === void 0 ? (_reportPossibleCrUseOfCharacterFabric({
          error: Error()
        }), CharacterFabric) : CharacterFabric
      }), _dec4 = property({
        type: _crd && GameUiMediator === void 0 ? (_reportPossibleCrUseOfGameUiMediator({
          error: Error()
        }), GameUiMediator) : GameUiMediator
      }), _dec5 = property({
        type: _crd && PlatformFabric === void 0 ? (_reportPossibleCrUseOfPlatformFabric({
          error: Error()
        }), PlatformFabric) : PlatformFabric
      }), _dec6 = property({
        type: _crd && PlayerProfile === void 0 ? (_reportPossibleCrUseOfPlayerProfile({
          error: Error()
        }), PlayerProfile) : PlayerProfile
      }), _dec(_class = (_class2 = class GameSceneContext extends (_crd && SceneContext === void 0 ? (_reportPossibleCrUseOfSceneContext({
        error: Error()
      }), SceneContext) : SceneContext) {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "gameStateMachine", _descriptor, this);

          _initializerDefineProperty(this, "characterFabric", _descriptor2, this);

          _initializerDefineProperty(this, "gameUiMediator", _descriptor3, this);

          _initializerDefineProperty(this, "platformFabric", _descriptor4, this);

          _initializerDefineProperty(this, "playerProfile", _descriptor5, this);
        }

        Init(pContext) {
          this.projectContext = pContext;
          this.InstallBindings();
          this.gameStateMachine.Init(this);
        }

        InstallBindings() {
          this.Bind(this.projectContext.GetDependency(_crd && SoundManager === void 0 ? (_reportPossibleCrUseOfSoundManager({
            error: Error()
          }), SoundManager) : SoundManager));
          this.Bind(this.projectContext.GetDependency(_crd && SaveLoad === void 0 ? (_reportPossibleCrUseOfSaveLoad({
            error: Error()
          }), SaveLoad) : SaveLoad));
          this.Bind(this.gameStateMachine);
          this.Bind(this.characterFabric);
          this.Bind(this.gameUiMediator);
          this.gameUiMediator.Init();
          this.Bind(this.platformFabric);
          this.platformFabric.Init();
          this.Bind(this.playerProfile);
          this.playerProfile.Init(this);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "gameStateMachine", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "characterFabric", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "gameUiMediator", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "platformFabric", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "playerProfile", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class);

      _export("default", GameSceneContext);

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=1f714a4bd367f4de849d765664c7492b7328989a.js.map