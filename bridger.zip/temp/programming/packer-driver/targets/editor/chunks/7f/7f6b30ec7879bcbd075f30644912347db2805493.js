System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, UITransform, Vec3, tween, Tween, CCFloat, Node, CCInteger, GetRandomNumberInRange, Stick, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _crd, ccclass, property, Platform;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfGetRandomNumberInRange(extras) {
    _reporterNs.report("GetRandomNumberInRange", "db://assets/Core/Utils/Utils", _context.meta, extras);
  }

  function _reportPossibleCrUseOfStick(extras) {
    _reporterNs.report("Stick", "./Stick", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      UITransform = _cc.UITransform;
      Vec3 = _cc.Vec3;
      tween = _cc.tween;
      Tween = _cc.Tween;
      CCFloat = _cc.CCFloat;
      Node = _cc.Node;
      CCInteger = _cc.CCInteger;
    }, function (_unresolved_2) {
      GetRandomNumberInRange = _unresolved_2.GetRandomNumberInRange;
    }, function (_unresolved_3) {
      Stick = _unresolved_3.Stick;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "a48ed14PRpH1q+IGFcRvFeb", "Platform", undefined);

      __checkObsolete__(['_decorator', 'Component', 'director', 'UITransform', 'Vec3', 'math', 'tween', 'Tween', 'CCFloat', 'Node', 'CCInteger']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Platform", Platform = (_dec = ccclass('Platform'), _dec2 = property({
        type: UITransform
      }), _dec3 = property({
        type: CCFloat
      }), _dec4 = property({
        type: _crd && Stick === void 0 ? (_reportPossibleCrUseOfStick({
          error: Error()
        }), Stick) : Stick
      }), _dec5 = property({
        type: Node
      }), _dec6 = property({
        type: CCInteger
      }), _dec7 = property({
        type: CCInteger
      }), _dec(_class = (_class2 = class Platform extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "transform", _descriptor, this);

          _initializerDefineProperty(this, "platformSize", _descriptor2, this);

          _initializerDefineProperty(this, "stick", _descriptor3, this);

          _initializerDefineProperty(this, "rewardZone", _descriptor4, this);

          _initializerDefineProperty(this, "minSize", _descriptor5, this);

          _initializerDefineProperty(this, "maxSize", _descriptor6, this);

          this.rewardSize = 20;
          this.nextMovingPoint = void 0;
        }

        SetSize(value) {
          this.platformSize = value;
          this.stick.node.position = new Vec3(value * 0.5, 0, 0);
          this.transform.setContentSize(value, this.transform.contentSize.y);
          this.UpdateMovingPointPosition(value);
        }

        WarpToPosition(newPosition) {
          this.node.position = newPosition;
        }

        MoveToPosition(newPosition) {
          let onCompleteCallback = () => this.UpdateMovingPointPosition(this.platformSize);

          return tween(this.node.position).to(0.2, newPosition, {
            onUpdate: target => {
              this.node.position = target;
            },
            onComplete: target => {
              onCompleteCallback();
            }
          });
        }

        UpdateMovingPointPosition(value) {
          const {
            x,
            y,
            z
          } = this.node.position;
          this.nextMovingPoint = new Vec3(x + value * 0.5, y, z);
        }

        RandomiseSize() {
          this.SetSize((_crd && GetRandomNumberInRange === void 0 ? (_reportPossibleCrUseOfGetRandomNumberInRange({
            error: Error()
          }), GetRandomNumberInRange) : GetRandomNumberInRange)(this.minSize, this.maxSize));
          return this.platformSize;
        }

        Reset() {
          this.stick.Reset();
          this.WarpToPosition(new Vec3(0, -1000, 0));
          Tween.stopAllByTarget(this.node.position);
        }

        SetStickValue(currentStickValue) {
          this.stick.SetSize(currentStickValue);
        }

        ShowReward() {
          this.rewardZone.active = true;
        }

        HideReward() {
          this.rewardZone.active = false;
        }

        RotateStick() {
          return this.stick.Rotate();
        }

        RotateStickToFall() {
          return this.stick.RotateToFall();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "transform", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "platformSize", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "stick", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "rewardZone", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "minSize", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 50;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "maxSize", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 120;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=7f6b30ec7879bcbd075f30644912347db2805493.js.map